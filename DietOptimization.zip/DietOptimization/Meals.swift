//
//  Meals.swift
//  DietOptimization
//
//  Created by Allen Geng on 17/1/13.
//  Copyright © 2017年 HD90+. All rights reserved.
//

import Foundation


class Meals{
    
    var mealType: String?
    
    var mealFoods: Foods?
    
    var mealDate: Date?
    
    var mealCost: Float?
    
    var mealCalory: Float?
    
    var mealProtein: Float?
    
    var mealSuger: Float?
    
    var mealFat: Float?
    
    
    
    var _mealType: String?{
        get{
            return mealType
        }
        
        set{
            mealType = newValue
        }
    }
    
    var _mealFoods: Foods?{
        get{
            return mealFoods
        }
        
        set{
            mealFoods = newValue
        }
    }
    
    var _mealDate: Date? {
        get{
            return mealDate
        }
        
        set{
            mealDate = newValue
        }
    }
    
    var _mealCost: Float {
        get{
            return mealCost!
        }
        
        set{
            mealCost = newValue
        }
    }
    
    var _mealCalory: Float {
        get{
            return mealCalory!
        }
        
        set{
            mealCalory = newValue
        }
    }
    
    var _mealProtein: Float{
        get{
            return mealProtein!
        }
        
        set{
            mealProtein = newValue
        }
    }
    
    var _mealSuger: Float{
        get{
            return mealSuger!
        }
        
        set{
            mealSuger = newValue
        }
    }
    
    var _mealFat: Float{
        get{
            return mealFat!
        }
        
        set{
            mealFat = newValue
        }
    }
    
    
    func caculateMealData(){
        //calculate the amount of nutrition of th meal
        
    
    }
    
}
