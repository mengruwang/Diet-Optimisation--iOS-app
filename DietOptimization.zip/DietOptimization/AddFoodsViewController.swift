//
//  AddFoodsViewController.swift
//  DietOptimization
//
//  Created by Allen Geng on 17/1/12.
//  Copyright © 2017年 HD90+. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

class AddFoodsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var arrayOfCellData = [cellData]()
        
    override func viewDidLoad() {
 
    }

   

    @IBAction func backDaily(_ sender: Any) {
        self.performSegue(withIdentifier: "unwindToDaily", sender: self)
        
    }
 
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayOfCellData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       
        let cell = Bundle.main.loadNibNamed("AddFoodTableViewCell", owner: self, options: nil)?.first as! AddFoodTableViewCell
            
        cell.mainImg.image = arrayOfCellData[indexPath.row].image
        cell.title.text = arrayOfCellData[indexPath.row].text
            
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 109
    }
    
    
    // MARK: - Table view data source

   
}
