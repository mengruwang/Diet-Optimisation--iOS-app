//
//  HomeViewController.swift
//  DietOptimization
//
//  Created by Allen Geng on 17/1/11.
//  Copyright © 2017年 HD90+. All rights reserved.
//

import UIKit
import Firebase

struct cellData {
    let cell: Int!
    let text: String!
    let image: UIImage!
}


class HomeViewController: UIViewController , UITableViewDelegate, UITableViewDataSource {
    @IBOutlet var SideMenu: UIBarButtonItem!
    var arrayOfCellData = [cellData]()
    
    var planRef: FIRDatabaseReference?
    var planHandle: FIRDatabaseHandle?
    
    
    //////////////////////
    var planDate: String?
    var planCost: Double?
    var planFat: Double?
    var planEnergy: Double?
    var stringDate: String?
    

    
    override func viewDidLoad() {
        
        
        self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        
        
        
        planRef = FIRDatabase.database().reference()
        
        
        
        self.planHandle = planRef?.child("Plan").observe(FIRDataEventType.value, with: {(snapshot) in
            
            let postDict = snapshot.value as! NSDictionary
            
            let dateFormatter = DateFormatter()
            
            dateFormatter.dateStyle = DateFormatter.Style.short
            let currentDate = Date()
            self.stringDate = dateFormatter.string(from: currentDate)
            
            print(postDict)
            
            for(id, value) in postDict{
                
                if let temp: String = ((value as! NSDictionary)["pDate"] as! String) {
                    
                    if temp  == self.stringDate{
                        
                        
                        self.planFat = ((value as! NSDictionary)["pFat"] as! Double)
                        self.planEnergy = ((value as! NSDictionary)["pEnergy"] as! Double)
                        self.planCost = ((value as! NSDictionary)["pCost"] as! Double)
                        
                        print("ppppp\(self.planFat)")
                        
                    }
                
                }else{
                    
                
                }
               
                
                
            }
            
        })

        
        SideMenu.target = self.revealViewController()
        SideMenu.action = Selector("revealToggle:")
        
        
        
        arrayOfCellData = [cellData(cell: 1, text: "Recommendation", image: #imageLiteral(resourceName: "ImageSAMPLE"))]
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayOfCellData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //this is a table view
            let cell = Bundle.main.loadNibNamed("RecommendationTableViewCell", owner: self, options: nil)?.first as! RecommendationTableViewCell
            cell.selectionStyle = .none // to prevent cells from being "highlighted"
            
            cell.mainImg.image = arrayOfCellData[indexPath.row].image
            cell.title.text = arrayOfCellData[indexPath.row].text
    
            
            return cell
       
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.performSegue(withIdentifier: "gotoRecommendation", sender: self)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
            return 279
        
        
    }
    
    @IBAction func unwindToHome(segue: UIStoryboardSegue){}
}
