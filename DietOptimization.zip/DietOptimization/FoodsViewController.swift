//
//  FoodsViewController.swift
//  DietOptimization
//
//  Created by Allen Geng on 17/1/11.
//  Copyright © 2017年 HD90+. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase


struct foodInfo {
    let name: String!
    let image: UIImage!
    let price: Double!
    let energy: Double!
    let protein: Double!
    let fat: Double!
    let carbohydrate: Double!
    let fibre: Double!
    let sugar: Double!
    let calcium: Double!
    let iron:Double!
    let sodium:Double!
    let zinc:Double!
    let c: Double!
    let a: Double!
    let e: Double!
    let d: Double!
    let serving: Int!
}

class FoodsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet var foodsTable: UITableView!

    @IBOutlet var SideMenu: UIBarButtonItem!
        var foodRef: FIRDatabaseReference?
    var foodRefHandle: FIRDatabaseHandle?
    
    var arrayOfCellData = [foodInfo]()
    
    var selectedFood = foodInfo(name: nil, image: nil, price: 0.0, energy: 0.0, protein: 0.0, fat: 0.0, carbohydrate: 0.0, fibre:0.0, sugar:0.0, calcium:0.0, iron:0.0, sodium: 0.0, zinc: 0.0, c:0.0, a:0.0, e:0.0, d:0.0, serving: 0)


    override func viewDidLoad() {
        
        //Retrieve data from database
        
        self.foodRef = FIRDatabase.database().reference()
        
        foodRefHandle = foodRef?.child("Food").observe(FIRDataEventType.value, with: {(snapshot) in
            let postDict = snapshot.value as! NSDictionary
        
            
            for(id, value) in postDict{
                var name: String = "fdName"
                var image: String = "fdImg"
                var price: String = "fdCost"
                var energy: String = "fdEnergy"
                var protein: String = "fdProtein"
                var fat: String = "fdFat"
                var carbohydrate: String = "fdCarbohydrate"
                var fibre: String = "fdFibre"
                var sugar: String = "fdSugar"
                var calcium: String = "fdCalcium"
                var iron: String = "fdIron"
                var sodium: String = "fdSodium"
                var zinc: String = "fdZinc"
                var c: String = "fdC"
                var a: String = "fdA"
                var e: String = "fdE"
                var d: String = "fdD"
                var serving: String = "fdUnit"
                
                var fdName: String = (((value as! NSDictionary)[name]) as! String)
                var fdImg: UIImage! = UIImage(named: ((value as! NSDictionary)[image]) as! String)
                var fdPrice: Double = (((value as! NSDictionary)[price]) as! Double)
                var fdEnergy: Double = (((value as! NSDictionary)[energy]) as! Double)
                var fdProtein: Double = (((value as! NSDictionary)[protein]) as! Double)
                var fdFat: Double = (((value as! NSDictionary)[fat]) as! Double)
                var fdCarbohydrate: Double = (((value as! NSDictionary)[carbohydrate]) as! Double)
                var fdFibre: Double = (((value as! NSDictionary)[fibre]) as! Double)
                var fdSugar: Double = (((value as! NSDictionary)[sugar]) as! Double)
                var fdCalcium: Double = (((value as! NSDictionary)[calcium]) as! Double)
                var fdIron: Double = (((value as! NSDictionary)[iron]) as! Double)
                var fdSodium: Double = (((value as! NSDictionary)[sodium]) as! Double)
                var fdZinc: Double = (((value as! NSDictionary)[zinc]) as! Double)
                var fdC: Double = (((value as! NSDictionary)[c]) as! Double)
                var fdA: Double = (((value as! NSDictionary)[a]) as! Double)
                var fdE: Double = (((value as! NSDictionary)[e]) as! Double)
                var fdD: Double = (((value as! NSDictionary)[d]) as! Double)
                var fdServing: Int = (((value as! NSDictionary)[serving]) as! Int)
                
                
                
                print("name\((value as! NSDictionary)[name]) ")
                //((value as!NSDictionary)["fdImage"]) as! String
                var food: foodInfo!
                
                food = foodInfo(name: fdName, image: fdImg, price: fdPrice, energy: fdEnergy, protein: fdProtein, fat: fdFat, carbohydrate: fdCarbohydrate, fibre: fdFibre, sugar: fdSugar, calcium: fdCalcium, iron: fdIron, sodium: fdSodium, zinc: fdZinc, c: fdC, a: fdA, e: fdE, d: fdD, serving: fdServing)
                
                self.arrayOfCellData.append(food)
                
            }

            
            self.foodsTable.reloadData()
            
            print("value\(postDict)")
        
        })

        
        
        
        super.viewDidLoad()
        
        self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        SideMenu.target = self.revealViewController()
        SideMenu.action = Selector("revealToggle:")
        

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
  
    @IBAction func createFoodAction(_ sender: Any) {
        self.performSegue(withIdentifier: "createFood", sender: self)
    }
    
    @IBAction func unwindtoFoods(segue: UIStoryboardSegue){
        
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayOfCellData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = Bundle.main.loadNibNamed("AddFoodTableViewCell", owner: self, options: nil)?.first as! AddFoodTableViewCell
        cell.selectionStyle = .none // to prevent cells from being "highlighted"
            
        cell.mainImg.image = arrayOfCellData[indexPath.row].image
        cell.title.text = arrayOfCellData[indexPath.row].name
        cell.servingSize.text =  String(arrayOfCellData[indexPath.row].serving)
        cell.cost.text = String(format:"%.2f", arrayOfCellData[indexPath.row].price)
        cell.energy.text = String(format:"%.2f", arrayOfCellData[indexPath.row].energy)
        
        if arrayOfCellData[indexPath.row].serving == 1 {
            cell.servingSizeName.text = "Size (EA):"
        }
            
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
       
            return 109
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let currentRow = self.arrayOfCellData[indexPath.row]
        selectedFood = currentRow

        self.performSegue(withIdentifier: "gotoFoodDetails", sender: self)
    }
    
    @IBAction func unwindToFoods(segue: UIStoryboardSegue){}
    
    
    //Pass value to next page by using segue
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if(segue.identifier == "gotoFoodDetails") {
            let vc = segue.destination as! FoodDetailsViewController
            vc.food=selectedFood
        }
    }
}
