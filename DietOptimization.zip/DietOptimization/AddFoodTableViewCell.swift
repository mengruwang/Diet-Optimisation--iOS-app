//
//  AddFoodTableViewCell.swift
//  DietOptimization
//
//  Created by Allen Geng on 17/1/14.
//  Copyright © 2017年 HD90+. All rights reserved.
//

import UIKit

class AddFoodTableViewCell: UITableViewCell {

    @IBOutlet var title: UILabel!
    @IBOutlet var mainImg: UIImageView!
    @IBOutlet var servingSizeName: UILabel!
    @IBOutlet var servingSize: UILabel!
    @IBOutlet var energy: UILabel!
    @IBOutlet var cost: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
