//
//  Food.swift
//  DietOptimization
//
//  Created by Allen Geng on 17/1/13.
//  Copyright © 2017年 HD90+. All rights reserved.
//

import Foundation

class Foods{
    
    var foodName: String?
    
    var foodBrand: String?
    
    var foodCost: Float?
    
    var foodCalory: Float?
    
    var foodSuger: Float?
    
    var foodProtein: Float?
    
    var foodFat: Float?
    
    var _foodName: String?{
        get{
            return foodName
        }
        
        set{
            foodName = newValue
        }
    }
    
    var _foodBrand: String?{
        get{
            return foodBrand
        }
        
        set{
            foodBrand = newValue
        }
    }
    
    var _foodCost: Float?{
        set{
            foodCost = newValue
        }
        
        get{
            return foodCost
        }
    }
    
    var _foodCalory: Float?{
        set{
            foodCalory = newValue
        }
        
        get{
            return foodCalory
        }
    }
    
    var _foodSuger: Float?{
        set{
            foodSuger = newValue
        }
    
        get{
            return foodSuger
        }
    }
    
    var _foodProtein: Float?{
        set{
            foodProtein = newValue
        }
        
        get{
            return foodProtein
        }
    }
    
    var _foodFat: Float?{
        set{
            foodFat = newValue
        }
        
        get{
            return foodFat
        }
    }
    
    
    
}
