//
//  WeeklyReportViewController.swift
//  DietOptimization
//
//  Created by Aquila on 15/01/2017.
//  Copyright © 2017 HD90+. All rights reserved.
//

import UIKit
import JBChartView

class WeeklyReportViewController: UIViewController, JBBarChartViewDelegate, JBBarChartViewDataSource {

    @IBAction func backToDailyView(_ sender: Any) {
        self.performSegue(withIdentifier: "backToDailyView", sender: self)
    }
    @IBOutlet weak var barChart: JBBarChartView!
    @IBOutlet weak var informationLabel: UILabel!
    var chartLegend = ["9-Jan","10-Jan","11-Jan","12-Jan","13-Jan","14-Jan","15-Jan"]
    var chartData = [ 7632, 4956, 5613, 5034, 4832, 7532, 5643]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        view.backgroundColor=UIColor.white
        
        //Bar chart Setup
        barChart.backgroundColor=UIColor.white
        barChart.delegate = self
        barChart.dataSource = self
        barChart.minimumValue = 0
        barChart.maximumValue = 8000
        
        //footer & header
        var footerView = UIView(frame:CGRectMake(0,0,barChart.frame.width,16))
        
        var footer1 = UILabel(frame:CGRectMake(0, 0, barChart.frame.width/2, 16))
        footer1.textColor = UIColor.black
        footer1.text = "\(chartLegend[0])"
        
        var footer2 = UILabel(frame:CGRectMake(barChart.frame.width/2, 0, barChart.frame.width/2, 16))
        footer2.textColor = UIColor.black
        footer2.text = "\(chartLegend[chartLegend.count-1])"
        footer2.textAlignment = NSTextAlignment.right
        
        footerView.addSubview(footer1)
        footerView.addSubview(footer2)
        
        var header = UILabel(frame:CGRectMake(0, 0, barChart.frame.width, 50))
        header.textColor=UIColor.black
        header.font = UIFont.systemFont(ofSize: 24)
        header.text = "Weekly Report for Week 1"
        header.textAlignment = NSTextAlignment.center
        
        barChart.footerView = footerView
        barChart.headerView = header
        
        barChart.reloadData()
        barChart.setState(.collapsed, animated: true)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        barChart.reloadData()
        var timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(WeeklyReportViewController.showChart), userInfo: nil, repeats: false)
        // userInfo may set to aye accordingly
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        hideChart()
        
    }
    
    func hideChart(){
        barChart.setState(.collapsed, animated: true)
    }
    func showChart(){
        barChart.setState(.expanded, animated: true)
    }
    
    func numberOfBars(in barChartView: JBBarChartView!) -> UInt {
        return UInt(chartData.count)
        // This is for single column bar chart∫
    }
    
    func barChartView(_ barChartView: JBBarChartView!, heightForBarViewAt index: UInt) -> CGFloat {
        return CGFloat(chartData[Int(index)])
    }
    
    func barChartView(_ barChartView: JBBarChartView!, colorForBarViewAt index: UInt) -> UIColor! {
        return(index % 2 == 0) ? UIColor(red: 216.0/255.0, green: 232.0/255.0, blue: 191.0/255.0, alpha: 1.0) : UIColor(red: 166.0/255.0, green: 214.0/255.0, blue: 196.0/255.0, alpha: 1.0)
    }
    
    func barChartView(_ barChartView: JBBarChartView!, didSelectBarAt index: UInt, touch touchPoint: CGPoint) {
        let data = chartData[Int(index)]
        let key =  chartLegend[Int(index)]
        
        informationLabel.text="\(data) KJ intake on \(key)"
    }
    
    func didDeselect(_ barChartView: JBBarChartView!) {
        informationLabel.text="Click on to view details"
    }
    
    func CGRectMake(_ x: CGFloat, _ y: CGFloat, _ width: CGFloat, _ height: CGFloat) -> CGRect {
        return CGRect(x: x, y: y, width: width, height: height)
    }    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
