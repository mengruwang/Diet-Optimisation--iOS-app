//
//  LogRegViewController.swift
//  DietOptimization
//
//  Created by Allen Geng on 17/1/12.
//  Copyright © 2017年 HD90+. All rights reserved.
//

import UIKit
import Firebase

class LogRegViewController: UIViewController {

    @IBOutlet var txtEmail: UITextField!
    @IBOutlet var txtPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        if let user = FIRAuth.auth()?.currentUser
        {
            self.performSegue(withIdentifier: "gotoHomePage", sender: self)
        }
       
        


        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    @IBAction func logAction(_ sender: UIButton) {
        
        if self.txtEmail.text == "" || self.txtPassword.text == ""
        {
            let alertController = UIAlertController(title: "Oh no!", message: "Please fill in all blank!", preferredStyle: .alert)
            
            let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alertController.addAction(defaultAction)
            
            self.present(alertController, animated: true, completion: nil)
            
        }
        else
        {
            FIRAuth.auth()?.signIn(withEmail: self.txtEmail.text!, password: self.txtPassword.text!, completion: {(user, error) in
                
                if error == nil
                {
                    self.performSegue(withIdentifier: "gotoHomePage", sender: self)
                    
                }
                else
                {
                    let alertController = UIAlertController(title: "Oh no!", message: error?.localizedDescription, preferredStyle: .alert)
                    
                    let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                    alertController.addAction(defaultAction)
                    
                    self.present(alertController, animated: true, completion: nil)
                }
                
                
            })
        }

    }
    @IBAction func closeEmail(_ sender: UITextField) {
        txtEmail.resignFirstResponder();
    }
    
    @IBAction func closePassword(_ sender: Any) {
        txtPassword.resignFirstResponder();
    }
    
    
    @IBAction func regAction(_ sender: UIButton) {
        
        if self.txtEmail.text == "" || self.txtPassword.text == ""
        {
            let alertController = UIAlertController(title: "Oh no!", message: "Please fill in all blank!", preferredStyle: .alert)
            
            let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alertController.addAction(defaultAction)
            
            self.present(alertController, animated: true, completion: nil )
            
            
        }
        else
        {
            FIRAuth.auth()?.createUser(withEmail: self.txtEmail.text!, password: self.txtPassword.text!, completion: {(user, error) in
                
                if error == nil
                {
                    self.performSegue(withIdentifier: "gotoHomePage", sender: self)
                    
                }
                else
                {
                    let alertController = UIAlertController(title:"Oh No!", message: error?.localizedDescription, preferredStyle: .alert)
                    
                    let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                    alertController.addAction(defaultAction)
                    
                    self.present(alertController, animated: true, completion: nil )
                }
                
            })
        }

    }
    
  
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
