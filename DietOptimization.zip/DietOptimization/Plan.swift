//
//  Plan.swift
//  DietOptimization
//
//  Created by Allen Geng on 17/1/13.
//  Copyright © 2017年 HD90+. All rights reserved.
//

import Foundation

class Plan{
    
    var planName: String?
    
    var planDate:  Date?
    
    var isConfirmed: Bool?
    
    var planType: String?
    
    var planMeals: Meals?
    
    var _planName: String {
        get{
            return planName!
        }
        
        set{
            planName = newValue
        }
    }
    
    var _planDate: Date {
        get{
            return planDate!
        }
        
        set{
            planDate = newValue
        }
    }
    
    var _isConfirmed: Bool {
        get{
            return isConfirmed!
        }
        
        set{
            isConfirmed = newValue
        }
    }
    
    var _planType: String {
        get{
            return planType!
        }
        
        set{
            planType = newValue
        }
    }
    
    var _planMeals: Meals {
        get{
            return planMeals!
        }
        
        set{
            planMeals = newValue
        }
    }
    
}
