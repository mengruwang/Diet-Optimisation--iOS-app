//
//  CombinedReportViewController.swift
//  DietOptimization
//
//  Created by Aquila on 15/01/2017.
//  Copyright © 2017 HD90+. All rights reserved.
//

import UIKit
import THCalendarDatePicker

class CombinedReportViewController: UIViewController, THDatePickerDelegate {

    @IBOutlet weak var titleCurrentDate: UILabel!
    @IBOutlet weak var historyButton: UIButton!
    @IBOutlet weak var labelPrice: UILabel!
    @IBOutlet weak var labelCalories: UILabel!
    @IBOutlet weak var labelKJoule: UILabel!
    //@IBOutlet weak var labelFat: UILabel!
    @IBOutlet weak var labelSaturatedFat: UILabel!
    @IBOutlet weak var labelCarbonHydrate: UILabel!
    @IBOutlet weak var labelSugar: UILabel!
    @IBOutlet weak var labelFiber: UILabel!
    @IBOutlet weak var labelProtein: UILabel!
    @IBOutlet weak var labelSodium: UILabel!
    @IBOutlet weak var labelVA: UILabel!
    @IBOutlet weak var labelVC: UILabel!
    @IBOutlet weak var labelIron: UILabel!
    
    @IBOutlet var SideMenu: UIBarButtonItem!
    
    
    
    var curDate : Date? = Date()
    lazy var formatter: DateFormatter = {
        var tmpFormatter = DateFormatter()
        tmpFormatter.dateFormat = "dd/MM/yyyy"
        return tmpFormatter
    }()
    lazy var datePicker : THDatePickerViewController = {
        let picker = THDatePickerViewController.datePicker()
        picker?.delegate = self
        picker?.date = self.curDate
        picker?.setAllowClearDate(false)
        picker?.setClearAsToday(false)
        picker?.setAutoCloseOnSelectDate(true)
        picker?.setAllowSelectionOfSelectedDate(true)
        picker?.setDisableYearSwitch(true)
        picker?.setDisableFutureSelection(true)
        picker?.setDaysInHistorySelection(365)
        picker?.setDaysInFutureSelection(1)
        picker?.setDateTimeZoneWithName("UTC")
        picker?.autoCloseCancelDelay = 5.0
        picker?.isRounded = true
        picker?.dateTitle = "View Diet History"
        picker?.selectedBackgroundColor = UIColor(red: 237.0/255.0, green: 135.0/255.0, blue: 143.0/255.0, alpha: 1.0)
        picker?.currentDateColor = UIColor(red: 242.0/255.0, green: 121.0/255.0, blue: 53.0/255.0, alpha: 1.0)
        picker?.currentDateColorSelected = UIColor.yellow
        return picker!
    }()
    
    //var tmpDailyRecord1 = DailyRecords(recordDate: Date(), recordCost: 23.95, recordCalory: 5643, recordProtein: 32.7, recordSuger: 43.21, recordFat: 15.2)
    //var tmpDailyRecord2 = DailyRecords(recordDate: Date()-86400, recordCost: 34.75, recordCalory: 7532, recordProtein: 45.16, recordSuger: 33.25, recordFat: 13.2)
    var sampleRecords = [DailyRecords]()
    //initialize the sample data sets
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        
        SideMenu.target = self.revealViewController()
        SideMenu.action = Selector("revealToggle:")
        

        // Do any additional setup after loading the view, typically from a nib.
        let thisDay=formatter.string(from: curDate!)
        titleCurrentDate.text = "\(thisDay)"
        
        sampleRecords.append(DailyRecords(recordDate: Date(), recordCost: 6.49, recordCalory: 326.1, recordProtein: 30.11, recordSuger: 43.21, recordFat: 15.2, recordKJoule:307))
        sampleRecords.append(DailyRecords(recordDate: Date()-86400, recordCost: 34.75, recordCalory: 96016.2, recordProtein: 45.16, recordSuger: 33.25, recordFat: 13.2, recordKJoule:402.1))
        sampleRecords.append(DailyRecords(recordDate: Date()-2*86400, recordCost: 18.2, recordCalory: 77147.6, recordProtein: 24.3, recordSuger: 21.3, recordFat: 9.8,recordKJoule:323.2))
        sampleRecords.append(DailyRecords(recordDate: Date()-3*86400, recordCost: 23.1, recordCalory: 95777.4, recordProtein: 23.1, recordSuger: 19.2, recordFat: 10.4,recordKJoule:401.5))
        sampleRecords.append(DailyRecords(recordDate: Date()-4*86400, recordCost: 20.4, recordCalory: 90523.7, recordProtein: 31.1, recordSuger: 14.3, recordFat: 13.6,recordKJoule:379.6))
        sampleRecords.append(DailyRecords(recordDate: Date()-5*86400, recordCost: 18.6, recordCalory: 86940.9, recordProtein: 27.3, recordSuger: 26.7, recordFat: 19.7,recordKJoule:364.2))
        sampleRecords.append(DailyRecords(recordDate: Date()-6*86400, recordCost: 31.3, recordCalory: 86223.4, recordProtein: 18.3, recordSuger: 28.2, recordFat: 17.3,recordKJoule:361.4))
        refreshContents()
        
        //labelPrice.text = "\(tmpDailyRecord1.recordCost!)"
        //labelCalories.text = "\(tmpDailyRecord1.recordCalory!)"
        //labelProtein.text = "\(tmpDailyRecord1.recordProtein!)"
        //labelSugar.text = "\(tmpDailyRecord1.recordSuger!)"
        //labelFat.text = "\(tmpDailyRecord1.recordFat!)"
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func refreshContents() {
        //historyButton.setTitle((curDate != nil ? formatter.string(from: curDate!) : "No date selected"), for: UIControlState())
        
        
        // search records for currently selected corresponding report
        let eligibledates  = sampleRecords.filter(
            {
                return (formatter.string(from:($0.recordDate)!)) == (formatter.string(from: curDate!))
            }
        )
        if eligibledates.count == 1{
            let thisDay=formatter.string(from: curDate!)
            titleCurrentDate.text = "\(thisDay)"
            labelPrice.text = "\(eligibledates[0].recordCost!)"
            labelCalories.text = "\(eligibledates[0].recordCalory!)"
            labelProtein.text = "\(eligibledates[0].recordProtein!)"
            labelSugar.text = "\(eligibledates[0].recordSuger!)"
            //labelFat.text = "\(eligibledates[0].recordFat!)"
            labelKJoule.text = "\(eligibledates[0].recordKJoule!)"
        }
        else if eligibledates.count == 0{
            var alert = UIAlertController(title: "Opps", message: "No Report Records on that day", preferredStyle: UIAlertControllerStyle.alert)
            let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: { (ACTION) in
                //do nothing
            })
            alert.addAction(okAction)
            self.present(alert, animated: true, completion: nil)
            titleCurrentDate.text = "Please Select a Date"
            labelPrice.text = "00"
            labelCalories.text = "00"
            labelProtein.text = "00"
            labelSugar.text = "00"
            //labelFat.text = "00"
            
        }
    }
    
    @IBAction func touchedButton(_ sender: Any) {
        datePicker.date = self.curDate
        datePicker.setDateHasItemsCallback { (date: Date?) -> Bool in
            let tmp = (arc4random() % 30)+1
            return (tmp % 5 == 0)
        }
        presentSemiViewController(datePicker, withOptions: [
            convertCfTypeToString(KNSemiModalOptionKeys.shadowOpacity) as String! : 0.3 as Float,
            convertCfTypeToString(KNSemiModalOptionKeys.animationDuration) as String! : 1.0 as Float,
            convertCfTypeToString(KNSemiModalOptionKeys.pushParentBack) as String! : false as Bool
            ])
    }
    
    @IBAction func goToWeekly(_ sender: Any) {
        self.performSegue(withIdentifier: "goToWeekly", sender: self)
    }
    
    //MARK: PASSING PARAMETERS INTO WEEKLY VIEW
    //override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    //    var destViewController : WeeklyReportViewController = segue.destinationViewController as
    //    WeeklyReportViewController
    //    destViewController.
    //}
    
    /* https://vandadnp.wordpress.com/2014/07/07/swift-convert-unmanaged-to-string/ */
    func convertCfTypeToString(_ cfValue: Unmanaged<NSString>!) -> String?{
        /* Coded by Vandad Nahavandipoor */
        let value = Unmanaged<CFString>.fromOpaque(
            cfValue.toOpaque()).takeUnretainedValue() as CFString
        if CFGetTypeID(value) == CFStringGetTypeID(){
            return value as String
        } else {
            return nil
        }
    }
    @IBAction func backToDailyView(Segue: UIStoryboardSegue){
        
    }
    
    // MARK: THDatePickerDelegate
    
    func datePickerDonePressed(_ datePicker: THDatePickerViewController!) {
        curDate = datePicker.date
        refreshContents()
        dismissSemiModalView()
    }
    
    func datePickerCancelPressed(_ datePicker: THDatePickerViewController!) {
        dismissSemiModalView()
    }
    
    func datePicker(_ datePicker: THDatePickerViewController!, selectedDate: Date!) {
        print("Date selected: ", formatter.string(from: selectedDate))
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
