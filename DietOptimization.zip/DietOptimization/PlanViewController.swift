//
//  PlanViewController.swift
//  DietOptimization
//
//  Created by Allen Geng on 17/1/13.
//  Copyright © 2017年 HD90+. All rights reserved.
//

import UIKit
import DLRadioButton


class PlanViewController: UIViewController {
    
    
    @IBOutlet var SideMenu: UIBarButtonItem!
    @IBOutlet var lowCalories: DLRadioButton!
    @IBOutlet var lowCost: DLRadioButton!
    @IBOutlet var highNurition: DLRadioButton!
    var selectedPlan: String!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        
        SideMenu.target = self.revealViewController()
        SideMenu.action = Selector("revealToggle:")
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func unwindToPlan2(_ sender: Any) {
        
        
        self.performSegue(withIdentifier: "unwindToPlan2", sender: self)
    }
   
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        
        if lowCalories.isSelected {
            selectedPlan = "lowCalories"
        }else if lowCost.isSelected {
            selectedPlan = "lowCost"
        }else if highNurition.isSelected {
            selectedPlan = "highNutrition"
        }
        
        
        if selectedPlan == nil {
            let alert = UIAlertController(title: "", message: "Please Choose a Plan Type!", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }else{
            
            if(segue.identifier == "gotoPlan2") {
                let vc = segue.destination as! Plan2ViewController
                vc.plan2SelectedPlan = selectedPlan
            }
            
        }
    }

    @IBAction func unwindToPlan1(segue: UIStoryboardSegue) {}
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
