//
//  DailyRecords.swift
//  DietOptimization
//
//  Created by Allen Geng on 17/1/13.
//  Copyright © 2017年 HD90+. All rights reserved.
//

import Foundation

class DailyRecords{
    
    var recordDate: Date?
    
    var recordCost: Float?
    
    var recordCalory: Float?
    
    var recordProtein: Float?
    
    var recordSuger: Float?
    
    var recordFat: Float?
    
    var recordKJoule: Float?
    
    required init(recordDate:Date, recordCost: Float, recordCalory: Float, recordProtein: Float,recordSuger: Float,recordFat: Float,recordKJoule: Float){
        self.recordDate=recordDate
        self.recordCost=recordCost
        self.recordCalory=recordCalory
        self.recordProtein=recordProtein
        self.recordSuger=recordSuger
        self.recordFat=recordFat
        self.recordKJoule=recordKJoule
    }
    
    var _recordDate: Date?{
        set{
            recordDate = newValue
        }
        
        get{
            return recordDate
        }
    }
    
    var _recordKJoule: Float?{
        set{
            recordKJoule = newValue
        }
        
        get{
            return recordKJoule
        }
    }
    
    var _recordCost: Float?{
        set{
            recordCost = newValue
        }
        
        get{
            return recordCost
        }
    }
    
    var _recordCalory: Float?{
        set{
            recordCalory = newValue
        }
        
        get{
            return recordCalory
        }
    }
    
    var _recordProtein: Float?{
        set{
            recordProtein = newValue
        }
        
        get{
            return recordProtein
        }
    }
    
    var _recordSuger: Float?{
        set{
            recordSuger = newValue
        }
        
        get{
            return recordSuger
        }
    }
    
    var _recordFat: Float?{
        set{
            recordFat = newValue
        }
        
        get{
            return recordFat
        }
    }
}
