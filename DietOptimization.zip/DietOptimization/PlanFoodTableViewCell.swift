//
//  PlanFoodTableViewCell.swift
//  DietOptimization
//
//  Created by Allen Geng on 17/1/14.
//  Copyright © 2017年 HD90+. All rights reserved.
//

import UIKit

class PlanFoodTableViewCell: UITableViewCell {

    @IBOutlet var mainImg: UIImageView!

    @IBOutlet var foodName: UILabel!
    
    @IBOutlet var foodPrice: UILabel!
    
    @IBOutlet var foodCalore: UILabel!
    
    @IBOutlet var foodUnit: UILabel!
    
    @IBOutlet var foodServingSize: UILabel!
}
