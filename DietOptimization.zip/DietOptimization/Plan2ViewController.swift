//
//  Plan2ViewController.swift
//  DietOptimization
//
//  Created by Allen Geng on 17/1/14.
//  Copyright © 2017年 HD90+. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase


struct foodData {
    let name: String!
    let id: Double!
    let image: UIImage!
    let price: Double!
    let energy: Double!
    let protein: Double!
    let fat: Double!
    let carbohydrate: Double!
    let fibre: Double!
    let calcium: Double!
    let c: Double!
    let unit: Int!
}

class Plan2ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    var arrayOfCellData = [foodData]()
    var arrayOfSelectedFood = [foodData]();
    var foodRef: FIRDatabaseReference?
    var foodRefHandle: FIRDatabaseHandle?
    var plan2SelectedPlan : String!
    
    
    
    var rawResult = [Double]()
    var optimizationResult = [results]()
    var optimizationAlert: Int!
    var selectedFood = [foodData]()
    var selectedFoodsArray = [[Double]]()
    var length: Int!
    

    @IBOutlet var foodsTable: UITableView!
    
    override func viewDidLoad() {
        
        // Do any additional setup after loading the view.
        
        self.foodRef = FIRDatabase.database().reference()
        foodRefHandle = foodRef?.child("Food").observe(FIRDataEventType.value, with: {(snapshot) in
        let postDict = snapshot.value as! NSDictionary
            
            
            for(id, value) in postDict{
                var name: String = "fdName"
                var id: String = "fdId"
                var path: String = "fdImg"
                var price: String = "fdCost"
                var energy: String = "fdEnergy"
                var protein: String = "fdProtein"
                var fat: String = "fdFat"
                var carbohydrate: String = "fdCarbohydrate"
                var fibre: String = "fdFibre"
                var calcium: String = "fdCalcium"
                var c: String = "fdC"
                var unit: String = "fdUnit"
                
                //print("name\((value as! NSDictionary)[name]) ")
                //((value as!NSDictionary)["fdImage"]) as! String
                
                self.arrayOfCellData.append(foodData(name: (((value as! NSDictionary)[name]) as! String),id: (((value as! NSDictionary)[id]) as! Double), image: UIImage(named: ((value as! NSDictionary)[path]) as! String),price: (((value as! NSDictionary)[price]) as! Double), energy: (((value as! NSDictionary)[energy]) as! Double), protein: (((value as! NSDictionary)[protein]) as! Double), fat: (((value as! NSDictionary)[fat]) as! Double), carbohydrate: (((value as! NSDictionary)[carbohydrate]) as! Double), fibre: (((value as! NSDictionary)[fibre]) as! Double), calcium: (((value as! NSDictionary)[calcium]) as! Double), c:(((value as! NSDictionary)[c]) as! Double), unit: (((value as! NSDictionary)[unit]) as! Int)))
                
            }
            
            self.foodsTable.reloadData()
            print("value\(postDict)")
        })
        
        
        print("from plan 2 -----------------------------------------plan")
        print(plan2SelectedPlan)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayOfCellData.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 109
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        let cell = Bundle.main.loadNibNamed("AddFoodTableViewCell", owner: self, options: nil)?.first as! AddFoodTableViewCell
        
        
        
       // cell.accessoryType = cell.isSelected ? .checkmark : .none
        //  cell.selectionStyle = .none // to prevent cells from being "highlighted"
        
    
        cell.mainImg.image = arrayOfCellData[indexPath.row].image
        cell.title.text = arrayOfCellData[indexPath.row].name
        cell.servingSize.text =  String(arrayOfCellData[indexPath.row].unit)
        cell.cost.text = String(format:"%.01f", arrayOfCellData[indexPath.row].price)
        cell.energy.text = String(format:"%.01f", arrayOfCellData[indexPath.row].energy)
        
        if arrayOfCellData[indexPath.row].unit == 1 {
            cell.servingSizeName.text = "Size (EA):"
        }

        return cell
    }
    
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
       // tableView.cellForRow(at: indexPath)?.accessoryType = .checkmark
        
        arrayOfSelectedFood.append(foodData(name: arrayOfCellData[indexPath.row].name, id: arrayOfCellData[indexPath.row].id, image: arrayOfCellData[indexPath.row].image, price: arrayOfCellData[indexPath.row].price, energy: arrayOfCellData[indexPath.row].energy, protein: arrayOfCellData[indexPath.row].protein, fat: arrayOfCellData[indexPath.row].fat, carbohydrate: arrayOfCellData[indexPath.row].carbohydrate, fibre: arrayOfCellData[indexPath.row].fibre, calcium: arrayOfCellData[indexPath.row].calcium, c: arrayOfCellData[indexPath.row].c, unit: arrayOfCellData[indexPath.row].unit))
        
    }
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        
        let foodToRemove = foodData(name: arrayOfCellData[indexPath.row].name,id: arrayOfCellData[indexPath.row].id, image: arrayOfCellData[indexPath.row].image, price: arrayOfCellData[indexPath.row].price, energy: arrayOfCellData[indexPath.row].energy, protein: arrayOfCellData[indexPath.row].protein, fat: arrayOfCellData[indexPath.row].fat, carbohydrate: arrayOfCellData[indexPath.row].carbohydrate, fibre: arrayOfCellData[indexPath.row].fibre, calcium: arrayOfCellData[indexPath.row].calcium, c: arrayOfCellData[indexPath.row].c, unit: arrayOfCellData[indexPath.row].unit)
        
        var counter: Int!
        var indexOfRemoveFood: Int!
        var found: Bool! = false
        
        counter = 0
        
        
        arrayOfSelectedFood.forEach { food in
            
            if(food.name == foodToRemove.name){
                indexOfRemoveFood = counter
                print(indexOfRemoveFood)
                found = true
            }
            counter = counter+1
        }
        
        if found == true {
            arrayOfSelectedFood.remove(at: indexOfRemoveFood)
        }
        
        tableView.cellForRow(at: indexPath)?.accessoryType = .none
        
    }

    
    @IBAction func unwindToPlan2(segue: UIStoryboardSegue) {}
    
    @IBAction func unwindToPlan1(_ sender: Any) {
         self.performSegue(withIdentifier: "unwindToPlan1", sender: self)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if(segue.identifier == "goToPlanGeneration") {
            
            if arrayOfSelectedFood.count == 0 {
                let alert = UIAlertController(title: "", message: "Please Choose Your Food!", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                
            } else{
                callAlgorithm()
                let vc = segue.destination as! Plan3ViewController
                vc.resultFoods.removeAll()
                vc.selectedFoods = arrayOfSelectedFood
                //vc.selectedFoods.removeAll()
                vc.resultFoods = optimizationResult
                optimizationResult.removeAll()
            }
        }
    }
    
    
    func callAlgorithm(){
        
        print(arrayOfSelectedFood)
        length = arrayOfSelectedFood.count
        var index:Int!
        index = 0
        selectedFoodsArray = [[Double]](repeating : [Double] (repeating : 0.01, count : 8), count : length)
        
        
        arrayOfSelectedFood.forEach{food in
            
            selectedFoodsArray[index][0] = food.price
            selectedFoodsArray[index][1] = food.energy
            selectedFoodsArray[index][2] = food.protein
            selectedFoodsArray[index][3] = food.fat
            selectedFoodsArray[index][4] = food.carbohydrate
            selectedFoodsArray[index][5] = food.fibre
            selectedFoodsArray[index][6] = food.calcium
            selectedFoodsArray[index][7] = food.c
            
            index = index + 1
        }
        
        if plan2SelectedPlan == "lowCalories" {
            callSimplexLowCalory(foodArray: selectedFoodsArray)
        } else if plan2SelectedPlan == "lowCost" {
            callSimplexLowCost(foodArray: selectedFoodsArray)
        } else if plan2SelectedPlan == "highNutrition" {
            callSimplexLowFat(foodArray: selectedFoodsArray)
        }
        
        
        convertToResult()
        
    }

    
    
    func callSimplexLowCost(foodArray :[[Double]]){
        
        let FooodInfoArray = foodArray
        let num = FooodInfoArray.count
        
        var costArr = [Double](repeating :0.0, count :num)
        
        var weightArr = [Double](repeating :1.0, count :num + 1)
        
        //var costArrLeft = [Double](repeating :0.0, count :num + 1)
        var energyArrLeft = [Double](repeating :0.0, count :num + 1)
        var proteinArrLeft = [Double](repeating :0.0, count :num + 1)
        var satFatArrLeft = [Double](repeating :0.0, count :num + 1)
        var carbohydrateArrLeft = [Double](repeating :0.0, count :num + 1)
        var fibreArrLeft = [Double](repeating :0.0, count :num + 1)
        var calciumArrLeft = [Double](repeating :0.0, count :num + 1)
        var vcArrLeft = [Double](repeating :0.0, count :num + 1)
        
        //var costArrRight = [Double](repeating :0.0, count :num + 1)
        var energyArrRight = [Double](repeating :0.0, count :num + 1)
        var proteinArrRight = [Double](repeating :0.0, count :num + 1)
        var satFatArrRight = [Double](repeating :0.0, count :num + 1)
        var carbohydrateArrRight = [Double](repeating :0.0, count :num + 1)
        var fibreArrRight = [Double](repeating :0.0, count :num + 1)
        var calciumArrRight = [Double](repeating :0.0, count :num + 1)
        var vcArrRight = [Double](repeating :0.0, count :num + 1)
        
        
        
        let indexOfCost = 0
        let indexOfEnergy = 1
        let indexOfProtein = 2
        let indexOfSatFat = 3
        let indexOfCarbohydrate = 4
        let indexOfFibre = 5
        let indexOfCal = 6
        let indexOfVC = 7
        
        
        
        
        
        for i in 0..<num
        {
            
            costArr[i] = FooodInfoArray[i][indexOfCost]
            energyArrLeft[i] = FooodInfoArray[i][indexOfEnergy]
            proteinArrLeft[i] = FooodInfoArray[i][indexOfProtein]
            satFatArrLeft[i] = FooodInfoArray[i][indexOfSatFat]
            carbohydrateArrLeft[i] = FooodInfoArray[i][indexOfCarbohydrate]
            fibreArrLeft[i] = FooodInfoArray[i][indexOfFibre]
            calciumArrLeft[i] = FooodInfoArray[i][indexOfCal]
            vcArrLeft[i] = FooodInfoArray[i][indexOfVC]
            
            
            //costArrRight[i] = FooodInfoArray[i][indexOfCost]
            energyArrRight[i] = FooodInfoArray[i][indexOfEnergy]
            proteinArrRight[i] = FooodInfoArray[i][indexOfProtein]
            satFatArrRight[i] = FooodInfoArray[i][indexOfSatFat]
            carbohydrateArrRight[i] = FooodInfoArray[i][indexOfCarbohydrate]
            fibreArrRight[i] = FooodInfoArray[i][indexOfFibre]
            calciumArrRight[i] = FooodInfoArray[i][indexOfCal]
            vcArrRight[i] = FooodInfoArray[i][indexOfVC]
            
        }
        //costArrLeft[num] =
        energyArrLeft[num] = 800.0
        proteinArrLeft[num] = 65.0
        satFatArrLeft[num] = 20.0
        carbohydrateArrLeft[num] = 0.2 * 2080.0
        fibreArrLeft[num] = 20.0
        calciumArrLeft[num] = 600.0
        vcArrLeft[num] = 60.0
        
        
        //costArrRight[num] =
        energyArrRight[num] = 2080.0
        proteinArrRight[num] = 45.0
        satFatArrRight[num] = 50.0
        carbohydrateArrRight[num] = 0.55 * 2080.0
        fibreArrRight[num] = 25.0
        calciumArrRight[num] = 700.0
        vcArrRight[num] = 100.0
        weightArr[num] = 15.0
        
        /*
         minimize cost
         
         55 <= protein <= 65
         0.2 * energy <= carbohydrate <= 0.55 * energy
         55 <= SatFat <= 65
         20 <= fibre <= 30
         60 mg <= vc <= 100mg
         600mg <= calcium <= 700mg
         1200 <= energy <= 2080
         
         */
        
        let a = [weightArr,satFatArrRight,  energyArrRight, proteinArrLeft,fibreArrLeft ]//subjects coeficients matrix
        
        let x = costArr;//taget function coeficients
        
        /*
         @param optimalResult: 1 means maximiza, -1 means minimize
         @param numberOfSubjects: the amount of total constraints, in this example is 6 as above
         @param numberOf
         */
        
        let lp = LinearProgram(optimalResult: -1,numberOfSubjects: 5,numberOfVariables: costArr.count,numberOfLessEqualto: 2,numberOfEqualto: 1,numberOfLargerEqualto: 2,subjectsMatrix: a, x: x)
        
        lp.solve()
        
        rawResult = lp.foodResult()
        optimizationAlert = lp.resultPrompt()
        
    }
    
    
    func callSimplexLowCalory(foodArray :[[Double]]){
        
        let FooodInfoArray = foodArray
        let num = FooodInfoArray.count
        
        var energyArr = [Double](repeating :0.0, count :num)
        
        var weightArr = [Double](repeating :1.0, count :num + 1)
        
        var costArrLeft = [Double](repeating :0.0, count :num + 1)
        //var energyArrLeft = [Double](repeating :0.0, count :num + 1)
        var proteinArrLeft = [Double](repeating :0.0, count :num + 1)
        var satFatArrLeft = [Double](repeating :0.0, count :num + 1)
        var carbohydrateArrLeft = [Double](repeating :0.0, count :num + 1)
        var fibreArrLeft = [Double](repeating :0.0, count :num + 1)
        var calciumArrLeft = [Double](repeating :0.0, count :num + 1)
        var vcArrLeft = [Double](repeating :0.0, count :num + 1)
        
        var costArrRight = [Double](repeating :0.0, count :num + 1)
        //var energyArrRight = [Double](repeating :0.0, count :num + 1)
        var proteinArrRight = [Double](repeating :0.0, count :num + 1)
        var satFatArrRight = [Double](repeating :0.0, count :num + 1)
        var carbohydrateArrRight = [Double](repeating :0.0, count :num + 1)
        var fibreArrRight = [Double](repeating :0.0, count :num + 1)
        var calciumArrRight = [Double](repeating :0.0, count :num + 1)
        var vcArrRight = [Double](repeating :0.0, count :num + 1)
        
        
        
        let indexOfCost = 0
        let indexOfEnergy = 1
        let indexOfProtein = 2
        let indexOfSatFat = 3
        let indexOfCarbohydrate = 4
        let indexOfFibre = 5
        let indexOfCal = 6
        let indexOfVC = 7
        
        
        
        
        
        for i in 0..<num
        {
            
            costArrLeft[i] = FooodInfoArray[i][indexOfCost]
            energyArr[i] = FooodInfoArray[i][indexOfEnergy]
            proteinArrLeft[i] = FooodInfoArray[i][indexOfProtein]
            satFatArrLeft[i] = FooodInfoArray[i][indexOfSatFat]
            carbohydrateArrLeft[i] = FooodInfoArray[i][indexOfCarbohydrate]
            fibreArrLeft[i] = FooodInfoArray[i][indexOfFibre]
            calciumArrLeft[i] = FooodInfoArray[i][indexOfCal]
            vcArrLeft[i] = FooodInfoArray[i][indexOfVC]
            
            
            costArrRight[i] = FooodInfoArray[i][indexOfCost]
            //energyArrRight[i] = FooodInfoArray[i][indexOfEnergy]
            proteinArrRight[i] = FooodInfoArray[i][indexOfProtein]
            satFatArrRight[i] = FooodInfoArray[i][indexOfSatFat]
            carbohydrateArrRight[i] = FooodInfoArray[i][indexOfCarbohydrate]
            fibreArrRight[i] = FooodInfoArray[i][indexOfFibre]
            calciumArrRight[i] = FooodInfoArray[i][indexOfCal]
            vcArrRight[i] = FooodInfoArray[i][indexOfVC]
            
        }
        costArrLeft[num] = 5.0
        // energyArrLeft[num] = 800.0
        proteinArrLeft[num] = 65.0
        satFatArrLeft[num] = 20.0
        carbohydrateArrLeft[num] = 0.2 * 2080.0
        fibreArrLeft[num] = 20.0
        calciumArrLeft[num] = 600.0
        vcArrLeft[num] = 60.0
        
        
        costArrRight[num] = 20.0
        //energyArrRight[num] = 2080.0
        proteinArrRight[num] = 45.0
        satFatArrRight[num] = 50.0
        carbohydrateArrRight[num] = 0.55 * 2080.0
        fibreArrRight[num] = 25.0
        calciumArrRight[num] = 700.0
        vcArrRight[num] = 100.0
        weightArr[num] = 15.0
        
        /*
         minimize cost
         
         55 <= protein <= 65
         0.2 * energy <= carbohydrate <= 0.55 * energy
         55 <= SatFat <= 65
         20 <= fibre <= 30
         60 mg <= vc <= 100mg
         600mg <= calcium <= 700mg
         1200 <= energy <= 2080
         
         */
        
        let a = [weightArr,costArrRight, satFatArrRight, proteinArrLeft,fibreArrLeft ]//subjects coeficients matrix
        
        let x = energyArr;//taget function coeficients
        
        /*
         @param optimalResult: 1 means maximiza, -1 means minimize
         @param numberOfSubjects: the amount of total constraints, in this example is 6 as above
         @param numberOf
         */
        
        let lp = LinearProgram(optimalResult: -1,numberOfSubjects: 5,numberOfVariables: energyArr.count,numberOfLessEqualto: 3,numberOfEqualto: 0,numberOfLargerEqualto: 2,subjectsMatrix: a, x: x)
        
        lp.solve()
        rawResult = lp.foodResult()
        optimizationAlert = lp.resultPrompt()
    }
    
    func callSimplexLowFat(foodArray :[[Double]]){
        
        let FooodInfoArray = foodArray
        let num = FooodInfoArray.count
        
        var satFatArr = [Double](repeating :0.0, count :num)
        
        var weightArr = [Double](repeating :1.0, count :num + 1)
        
        var costArrLeft = [Double](repeating :0.0, count :num + 1)
        var energyArrLeft = [Double](repeating :0.0, count :num + 1)
        var proteinArrLeft = [Double](repeating :0.0, count :num + 1)
        //var satFatArrLeft = [Double](repeating :0.0, count :num + 1)
        var carbohydrateArrLeft = [Double](repeating :0.0, count :num + 1)
        var fibreArrLeft = [Double](repeating :0.0, count :num + 1)
        var calciumArrLeft = [Double](repeating :0.0, count :num + 1)
        var vcArrLeft = [Double](repeating :0.0, count :num + 1)
        
        var costArrRight = [Double](repeating :0.0, count :num + 1)
        var energyArrRight = [Double](repeating :0.0, count :num + 1)
        var proteinArrRight = [Double](repeating :0.0, count :num + 1)
        // var satFatArrRight = [Double](repeating :0.0, count :num + 1)
        var carbohydrateArrRight = [Double](repeating :0.0, count :num + 1)
        var fibreArrRight = [Double](repeating :0.0, count :num + 1)
        var calciumArrRight = [Double](repeating :0.0, count :num + 1)
        var vcArrRight = [Double](repeating :0.0, count :num + 1)
        
        
        
        let indexOfCost = 0
        let indexOfEnergy = 1
        let indexOfProtein = 2
        let indexOfSatFat = 3
        let indexOfCarbohydrate = 4
        let indexOfFibre = 5
        let indexOfCal = 6
        let indexOfVC = 7
        
        
        
        
        
        for i in 0..<num
        {
            
            costArrLeft[i] = FooodInfoArray[i][indexOfCost]
            energyArrLeft[i] = FooodInfoArray[i][indexOfEnergy]
            proteinArrLeft[i] = FooodInfoArray[i][indexOfProtein]
            satFatArr[i] = FooodInfoArray[i][indexOfSatFat]
            carbohydrateArrLeft[i] = FooodInfoArray[i][indexOfCarbohydrate]
            fibreArrLeft[i] = FooodInfoArray[i][indexOfFibre]
            calciumArrLeft[i] = FooodInfoArray[i][indexOfCal]
            vcArrLeft[i] = FooodInfoArray[i][indexOfVC]
            
            
            costArrRight[i] = FooodInfoArray[i][indexOfCost]
            energyArrRight[i] = FooodInfoArray[i][indexOfEnergy]
            proteinArrRight[i] = FooodInfoArray[i][indexOfProtein]
            //satFatArrRight[i] = FooodInfoArray[i][indexOfSatFat]
            carbohydrateArrRight[i] = FooodInfoArray[i][indexOfCarbohydrate]
            fibreArrRight[i] = FooodInfoArray[i][indexOfFibre]
            calciumArrRight[i] = FooodInfoArray[i][indexOfCal]
            vcArrRight[i] = FooodInfoArray[i][indexOfVC]
            
        }
        costArrLeft[num] = 5.0
        energyArrLeft[num] = 800.0
        proteinArrLeft[num] = 65.0
        //satFatArrLeft[num] = 20.0
        carbohydrateArrLeft[num] = 0.2 * 2080.0
        fibreArrLeft[num] = 20.0
        calciumArrLeft[num] = 600.0
        vcArrLeft[num] = 60.0
        
        
        costArrRight[num] = 20.0
        energyArrRight[num] = 2080.0
        proteinArrRight[num] = 45.0
        //satFatArrRight[num] = 50.0
        carbohydrateArrRight[num] = 0.55 * 2080.0
        fibreArrRight[num] = 25.0
        calciumArrRight[num] = 700.0
        vcArrRight[num] = 100.0
        weightArr[num] = 15.0
        
        /*
         minimize cost
         
         55 <= protein <= 65
         0.2 * energy <= carbohydrate <= 0.55 * energy
         55 <= SatFat <= 65
         20 <= fibre <= 30
         60 mg <= vc <= 100mg
         600mg <= calcium <= 700mg
         1200 <= energy <= 2080
         
         */
        
        let a = [weightArr,costArrRight,  energyArrRight, proteinArrLeft,fibreArrLeft ]//subjects coeficients matrix
        
        let x = satFatArr;//taget function coeficients
        
        /*
         @param optimalResult: 1 means maximiza, -1 means minimize
         @param numberOfSubjects: the amount of total constraints, in this example is 6 as above
         @param numberOf
         */
        
        let lp = LinearProgram(optimalResult: -1,numberOfSubjects: 5,numberOfVariables: satFatArr.count,numberOfLessEqualto: 2,numberOfEqualto: 1,numberOfLargerEqualto: 2,subjectsMatrix: a, x: x)
        
        lp.solve()
        rawResult = lp.foodResult()
        optimizationAlert = lp.resultPrompt()
        // 0 - has results
        // 1 - parameter input error
        // 2 - no boundarie solutions
        // 3 - nosolutions
        
        
    }
    
    func convertToResult(){
        var count: Int!
        count = 0
        
        if (optimizationAlert != nil) {
            //selectedFood
            //optimizationResult
            arrayOfSelectedFood.forEach{ food in
                if (rawResult[count] != 0.0){
                    optimizationResult.append(results( name: food.name,image: food.image, price: food.price, energy: food.energy, protein: food.protein, fat: food.fat, carbohydrate: food.carbohydrate, fibre: food.fibre, calcium: food.calcium, c: food.c, unit: food.unit, numberOfServing: rawResult[count] ))
                }
                
                count = count + 1
            }
            
        }
        
    }
    
    
   
    

    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
