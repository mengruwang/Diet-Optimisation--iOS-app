//
//  PlanChoiceTableViewCell.swift
//  DietOptimization
//
//  Created by 赵鹏翀 on 15/1/17.
//  Copyright © 2017 HD90+. All rights reserved.
//

import UIKit

class PlanChoiceTableViewCell: UITableViewCell {

    @IBOutlet var planChoice: UILabel!
       
}
