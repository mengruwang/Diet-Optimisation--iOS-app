//
//  ReportsViewController.swift
//  DietOptimization
//
//  Created by Allen Geng on 17/1/11.
//  Copyright © 2017年 HD90+. All rights reserved.
//

import UIKit

class ReportsViewController: UIViewController {

    @IBOutlet var SideMenu: UIBarButtonItem!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())

        SideMenu.target = self.revealViewController()
        SideMenu.action = Selector("revealToggle:")
        

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
