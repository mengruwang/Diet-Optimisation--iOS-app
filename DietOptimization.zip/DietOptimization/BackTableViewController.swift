//
//  BackTableViewController.swift
//  DietOptimization
//
//  Created by Allen Geng on 17/1/11.
//  Copyright © 2017年 HD90+. All rights reserved.
//

import Foundation
import Firebase


class BackTableVC: UITableViewController {
    
    var TableArray = [String]()
    var cellIcons = [UIImage]()
    var email: String?
    
    override func viewDidLoad() {
        //self.edgesForExtendedLayout=UIRectEdge.top
        
        //self.extendedLayoutIncludesOpaqueBars=true
        //self.automaticallyAdjustsScrollViewInsets=true
        self.view.backgroundColor = UIColor(red: 255/255.0, green: 240/255.0, blue:230/255.0, alpha: 1)
        //self.view.backgroundColor = UIColor(patternImage: UIImage(named: "sidebarbg.png")!)
        
        TableArray = ["Home", "Daily", "Foods", "Report", "Settings","Plan"]
        //append images to icon array
        cellIcons.append(#imageLiteral(resourceName: "Icons-HomeSketch"))
        cellIcons.append(#imageLiteral(resourceName: "Icons-DailySketch"))
        cellIcons.append(#imageLiteral(resourceName: "Icons-FoodsSketch"))
        cellIcons.append(#imageLiteral(resourceName: "Icons-ReportSketch"))
        cellIcons.append(#imageLiteral(resourceName: "Icons-SettingSketch"))
        cellIcons.append(#imageLiteral(resourceName: "Icons-GoalSketch"))
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return TableArray.count+1
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0{
            let cell = Bundle.main.loadNibNamed("LargeTableViewCell", owner: self, options: nil)?.first as! LargeTableViewCell
            //let bkgd = UIImage(#colorLiteral(red: 0.8470588235, green: 0.9098039216, blue: 0.7490196078, alpha: 1))
            //cell.mainImageView!.image = UIImage(UIColor(red: 216, green: 232, blue: 191, alpha: 1))
            //cell.mainImageView!.image = getImageWithColor(color: UIColor(red: 216, green: 232, blue: 191, alpha: 1), size: CGSize(width: 320, height: 146))
            cell.mainImageView!.image = #imageLiteral(resourceName: "Abo-Hani-Android-6.0-Marshmallow-inspired-wallpapers-collection-in-1080p")
            cell.potraitImageView!.image = #imageLiteral(resourceName: "portrait")
            
            if let user = FIRAuth.auth()?.currentUser {
                
                self.email = user.email!
                
            }
            cell.mainLabel.text = "G'Day, \(email! as String)!"
            //RGB: 242, 165, 162 RGB:166, 214, 196
            //cell.mainLabel.textColor=UIColor(red: 166/255.0, green: 214/255.0, blue: 196/255.0, alpha: 1.0)
            return cell
        }
        else if indexPath.row == 1{
            let cell = tableView.dequeueReusableCell(withIdentifier: "Home", for: indexPath) as UITableViewCell
            cell.backgroundColor = UIColor(red: 255/255.0, green: 240/255.0, blue:230/255.0, alpha: 1)
            cell.textLabel?.text = TableArray[0]
            cell.textLabel?.textColor=UIColor(red: 166/255.0, green: 214/255.0, blue: 196/255.0, alpha: 1.0)
            cell.textLabel?.font = UIFont(name: "EurostileLTstd-Demi", size: 18)
            cell.imageView?.image = cellIcons[0]
            return cell
        }
        else if indexPath.row == 2{
            let cell = tableView.dequeueReusableCell(withIdentifier: "Daily", for: indexPath) as UITableViewCell
            cell.backgroundColor = UIColor(red: 255/255.0, green: 240/255.0, blue:230/255.0, alpha: 1)
            cell.textLabel?.text = TableArray[1]
            cell.textLabel?.textColor=UIColor(red: 166/255.0, green: 214/255.0, blue: 196/255.0, alpha: 1.0)
            cell.textLabel?.font = UIFont(name: "EurostileLTstd-Demi", size: 18)
            cell.imageView?.image = cellIcons[1]
            return cell
        }
        else if indexPath.row == 3{
            let cell = tableView.dequeueReusableCell(withIdentifier: "Foods", for: indexPath) as UITableViewCell
            cell.backgroundColor = UIColor(red: 255/255.0, green: 240/255.0, blue:230/255.0, alpha: 1)
            cell.textLabel?.text = TableArray[2]
            cell.textLabel?.textColor=UIColor(red: 166/255.0, green: 214/255.0, blue: 196/255.0, alpha: 1.0)
            cell.textLabel?.font = UIFont(name: "EurostileLTstd-Demi", size: 18)
            cell.imageView?.image = cellIcons[2]
            return cell
        }
        else if indexPath.row == 4{
            let cell = tableView.dequeueReusableCell(withIdentifier: "Report", for: indexPath) as UITableViewCell
            cell.backgroundColor = UIColor(red: 255/255.0, green: 240/255.0, blue:230/255.0, alpha: 1)
            cell.textLabel?.text = TableArray[3]
            cell.textLabel?.textColor=UIColor(red: 166/255.0, green: 214/255.0, blue: 196/255.0, alpha: 1.0)
            cell.textLabel?.font = UIFont(name: "EurostileLTstd-Demi", size: 18)
            cell.imageView?.image = cellIcons[3]
            return cell
        }
        else if indexPath.row == 5{
            let cell = tableView.dequeueReusableCell(withIdentifier: "Settings", for: indexPath) as UITableViewCell
            cell.backgroundColor = UIColor(red: 255/255.0, green: 240/255.0, blue:230/255.0, alpha: 1)
            cell.textLabel?.text = TableArray[4]
            cell.textLabel?.textColor=UIColor(red: 166/255.0, green: 214/255.0, blue: 196/255.0, alpha: 1.0)
            cell.textLabel?.font = UIFont(name: "EurostileLTstd-Demi", size: 18)
            cell.imageView?.image = cellIcons[4]
            return cell
        }
        else if indexPath.row == 6{
            let cell = tableView.dequeueReusableCell(withIdentifier: "Plan", for: indexPath) as UITableViewCell
            cell.backgroundColor = UIColor(red: 255/255.0, green: 240/255.0, blue:230/255.0, alpha: 1)
            cell.textLabel?.text = TableArray[5]
            cell.textLabel?.textColor=UIColor(red: 166/255.0, green: 214/255.0, blue: 196/255.0, alpha: 1.0)
            cell.textLabel?.font = UIFont(name: "EurostileLTstd-Demi", size: 18)
            cell.imageView?.image = cellIcons[5]
            return cell
        }
        else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "empty", for: indexPath) as UITableViewCell
            cell.backgroundColor = UIColor(red: 255/255.0, green: 240/255.0, blue:230/255.0, alpha: 1)
            return cell
        }
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        switch indexPath.row {
        case 0:
            return 147
        case 1:
            return 44
        case 2:
            return 44
        case 3:
            return 44
        case 4:
            return 44
        case 5:
            return 44
        case 6:
            return 44
        default:
            return 44
        }
        
    }
    func getImageWithColor(color: UIColor, size: CGSize) -> UIImage {
        let rect = CGRect(origin: .zero, size: size)
        UIGraphicsBeginImageContextWithOptions(rect.size, false, 0.0)
        color.setFill()
        UIRectFill(rect)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image!
    }
    
    
    
}
