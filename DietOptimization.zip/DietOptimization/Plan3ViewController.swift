//
//  Plan3ViewController.swift
//  DietOptimization
//
//  Created by 赵鹏翀 on 2017/1/15.
//  Copyright © 2017年 HD90+. All rights reserved.
//

import UIKit
import Firebase


struct results {
    let name: String!
    let image: UIImage!
    let price: Double!
    let energy: Double!
    let protein: Double!
    let fat: Double!
    let carbohydrate: Double!
    let fibre: Double!
    let calcium: Double!
    let c: Double!
    let unit: Int!
    let numberOfServing: Double!
}

class ResultViewController: UIViewController {
    
    
    
    
    var oCost:String!
    var oEnergy: String!
    var oFat: String!
    var sCost: String!
    var sEnergy: String!
    var sFat: String!
    
    @IBOutlet var optimizationCost: UILabel!
    
    @IBOutlet var selectedCost: UILabel!
    
    @IBOutlet var optimizationEnergy: UILabel!
    
    @IBOutlet var selectedEnergy: UILabel!
    
    @IBOutlet var optimizationFat: UILabel!
    
    @IBOutlet var selectedFat: UILabel!
    
    func myMethod() {
        optimizationCost.text = oCost;
        optimizationFat.text = oFat;
        optimizationEnergy.text = oEnergy;
        selectedCost.text = sCost;
        selectedEnergy.text = sEnergy;
        selectedFat.text = sFat;
        
    }
}

class Plan3ViewController: UIViewController,UITableViewDelegate, UITableViewDataSource {
    
    
    @IBOutlet var optimizationCost: UILabel!
    
    @IBOutlet var planResultView: UIView!
    
    var oCost:Double!
    var oEnergy:Double!
    var oFat:Double!
    
    var sCost: Double!
    var sEnergy: Double!
    var sFat: Double!
    var stringDate: String?
    
    var planRef: FIRDatabaseReference?
    
    
    
    ///var planFoods = [foodData]()
    var resultFoods = [results]()
    var selectedFoods = [foodData]()
    
    override func viewDidLoad() {
        
    }
    
    @IBAction func savePlan(_ sender: Any) {
        
        
        let alertController = UIAlertController(title: "System Alert",
                                                message: "Confirm to Generate the Plan？", preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "cancel", style: .cancel, handler: nil)
        let okAction = UIAlertAction(title: "yes", style: .default, handler: {
            action in
            
            self.planRef = FIRDatabase.database().reference()
            
            var dateFormatter = DateFormatter()
            
            dateFormatter.dateStyle = DateFormatter.Style.short
            let currentDate = Date()
            self.stringDate = dateFormatter.string(from: currentDate)
            
            
          //  print(stringDate)
            
            
            let plan = ["pCost": self.oCost,
                        "pEnergy": self.oEnergy,
                        "pFat": self.oFat,
                        "pDate": self.stringDate] as [String : Any]
            
            self.planRef?.child("Plan").childByAutoId().setValue(plan)
            
            
            
            self.performSegue(withIdentifier: "gotoHome", sender: self)
            
        })
        alertController.addAction(cancelAction)
        alertController.addAction(okAction)
        self.present(alertController, animated: true, completion: nil)
        
        
        
        
        
    }
        
    @IBAction func unwindToPlan2(_ sender: Any) {
        
         self.performSegue(withIdentifier: "unwindToPlan2", sender: self)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return resultFoods.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 109
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = Bundle.main.loadNibNamed("PlanFoodTableViewCell", owner: self, options: nil)?.first as! PlanFoodTableViewCell
            
        cell.mainImg.image = resultFoods[indexPath.row].image
        cell.foodName.text = resultFoods[indexPath.row].name
        cell.foodPrice.text = String(format:"%.2f", resultFoods[indexPath.row].price)
        cell.foodCalore.text = String(format:"%.2f", resultFoods[indexPath.row].energy)
        cell.foodUnit.text = String(format:"%.2f", resultFoods[indexPath.row].numberOfServing)+" x "+String(resultFoods[indexPath.row].unit)
        
        if resultFoods[indexPath.row].unit == 1 {
            cell.foodServingSize.text = "Size (EA):"
        }
        
        return cell
    }
    @IBAction func unwindToDaily(_ sender: Any) {
        
        self.performSegue(withIdentifier: "unwindToDaily", sender: self)
    }
    
    
    private var embeddedViewController: ResultViewController!
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "planEmbedSegue" {
            
            let vc = segue.destination as? ResultViewController
            self.embeddedViewController = vc
            calculate()
            
            print(oEnergy)
            print(String(format:"%.2f",oEnergy))
            
            embeddedViewController.oCost = String(format:"%.2f",oCost);
            embeddedViewController.oEnergy = String(format:"%.2f",oEnergy);
            embeddedViewController.oFat = String(format:"%.2f",oFat);
            embeddedViewController.sCost = String(format:"%.2f",sCost);
            embeddedViewController.sEnergy = String(format:"%.2f",sEnergy);
            embeddedViewController.sFat = String(format:"%.2f",sFat);
            //embeddedViewController.optimizationCost.text="aaaaa"
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.embeddedViewController.myMethod()
    }
    
    
    func calculate() {
        
        var resultNum:Int!
        var selectNum:Int!
        
        print("result food!!!!!!!!!!!!!!!!!!!!!!!")
        print(resultFoods)
        print("select food!!!!!!!!!!!!!!!!!!!!!!!!!")
        print(selectedFoods)
        
        resultNum = resultFoods.count
        selectNum = selectedFoods.count
        
        oCost = 0.0
        oEnergy = 0.0
        oFat = 0.0
        
        sCost = 0.0
        sEnergy = 0.0
        sFat = 0.0

        
        for index in 0..<resultNum {
            oCost = oCost + resultFoods[index].price * resultFoods[index].numberOfServing
            oEnergy = oEnergy + resultFoods[index].energy * resultFoods[index].numberOfServing
            oFat = oFat + resultFoods[index].fat * resultFoods[index].numberOfServing
//            print(oCost)
//            print(oEnergy)
//            print(oFat)
        }
        
        for index in 0..<selectNum {
            sCost = sCost + selectedFoods[index].price
            sEnergy = sEnergy + selectedFoods[index].energy
            sFat = sFat + selectedFoods[index].fat
        }
        
    }
  

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
