//
//  Report.swift
//  DietOptimization
//
//  Created by Allen Geng on 17/1/13.
//  Copyright © 2017年 HD90+. All rights reserved.
//

import Foundation

class Report{

    
}
