//
//  FoodDetailsViewController.swift
//  DietOptimization
//
//  Created by Allen Geng on 17/1/15.
//  Copyright © 2017年 HD90+. All rights reserved.
//

import UIKit

class FoodDetailsViewController: UIViewController {
    
    var food: foodInfo!
    
    @IBOutlet var foodImg: UIImageView!
    @IBOutlet var foodName: UILabel!
    @IBOutlet var foodServing: UILabel!
    @IBOutlet var foodPrice: UILabel!
    @IBOutlet var foodCalories: UILabel!
    @IBOutlet var foodProtein: UILabel!
    @IBOutlet var foodFat: UILabel!
    @IBOutlet var foodCarbohydrate: UILabel!
    @IBOutlet var foodFibre: UILabel!
    @IBOutlet var foodSugar: UILabel!
    @IBOutlet var foodCalcium: UILabel!
    @IBOutlet var foodIron: UILabel!
    @IBOutlet var foodSodium: UILabel!
    @IBOutlet var foodZinc: UILabel!
    @IBOutlet var foodC: UILabel!
    @IBOutlet var foodA: UILabel!
    @IBOutlet var foodE: UILabel!
    @IBOutlet var foodD: UILabel!
    
    @IBOutlet var servingSize: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("from detail")
        print(food)
        foodImg.image = food.image
        foodName.text = food.name
        foodServing.text = String(food.serving)
        foodPrice.text = String(format:"%.2f", food.price)
        foodCalories.text = String(format:"%.2f", food.energy)
        foodFat.text = String(format:"%.3f", food.fat)
        foodCarbohydrate.text = String(format:"%.2f", food.carbohydrate)
        foodFibre.text = String(format:"%.2f", food.fibre)
        foodSugar.text = String(format:"%.2f", food.sugar)
        foodCalcium.text = String(format:"%.2f", food.calcium)
        foodIron.text = String(format:"%.2f", food.iron)
        foodSodium.text = String(format:"%.2f", food.sodium)
        foodZinc.text = String(format:"%.2f", food.zinc)
        foodC.text = String(format:"%.2f", food.c)
        foodA.text = String(format:"%.2f", food.a)
        foodE.text = String(format:"%.2f", food.e)
        foodD.text = String(format:"%.2f", food.d)
        
        if food.serving == 1 {
            servingSize.text = "Serving Size (EA):"
        }
        
        //foodSugar.text = String(format:"%.01f", food.sugar)
        

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func unwindToFoods(_ sender: Any) {
        
        self.performSegue(withIdentifier: "unwindToFoods", sender: self)
    }
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
