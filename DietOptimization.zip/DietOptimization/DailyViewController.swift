//
//  DailyViewController.swift
//  DietOptimization
//
//  Created by Allen Geng on 17/1/11.
//  Copyright © 2017年 HD90+. All rights reserved.
//

import UIKit

class DailyViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{
    @IBOutlet var foodTable: UITableView!
    
    //daily view controller

    var arrayOfCellData = [cellData]()
    @IBOutlet var SideMenu: UIBarButtonItem!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())

        SideMenu.target = self.revealViewController()
        SideMenu.action = Selector("revealToggle:")
        
        arrayOfCellData = [cellData(cell: 1, text: "Beef", image: #imageLiteral(resourceName: "beef")),
                           cellData(cell: 2, text: "Baby Spinach", image: #imageLiteral(resourceName: "spinach")),
                           cellData(cell: 3, text: "Broccoli", image: #imageLiteral(resourceName: "broccoli"))]
        

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
   
    @IBAction func gotoFood(_ sender: Any) {
        let alertController = UIAlertController(title: "System Alert",
                                                message: "Sure to Confirm?", preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "cancle", style: .cancel, handler: nil)
        let okAction = UIAlertAction(title: "yes", style: .default, handler: {
            action in
            self.arrayOfCellData.removeAll()
            self.foodTable.reloadData()
        })
        alertController.addAction(cancelAction)
        alertController.addAction(okAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
    @IBAction func unwindToDaily(segue: UIStoryboardSegue){}
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayOfCellData.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
       
            return 109
       
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = Bundle.main.loadNibNamed("AddFoodTableViewCell", owner: self, options: nil)?.first as! AddFoodTableViewCell
        cell.selectionStyle = .none // to prevent cells from being "highlighted"
            
        cell.mainImg.image = arrayOfCellData[indexPath.row].image
        cell.title.text = arrayOfCellData[indexPath.row].text
        
        return cell
        
    }

    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
