//
//  ViewController.swift
//  DietOptimization
//
//  Created by Randy-mac on 16/12/10.
//  Copyright © 2016年 HD90+. All rights reserved.
//

import UIKit
class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var arrayOfCellData = [cellData]()
    
    override func viewDidLoad() {
        arrayOfCellData = [cellData(cell: 1, text: "Beef", image: #imageLiteral(resourceName: "Icons-GoalSketch")),
                           cellData(cell: 2, text: "Lamb", image: #imageLiteral(resourceName: "Icons-PriceSketch")),
                           cellData(cell: 3, text: "Chicken", image: #imageLiteral(resourceName: "Icons-AccountSketch"))]
    }
    
    
    
    @IBAction func backDaily(_ sender: Any) {
        self.performSegue(withIdentifier: "unwindToDaily", sender: self)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayOfCellData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if arrayOfCellData[indexPath.row].cell == 1
        {
            let cell = Bundle.main.loadNibNamed("AddFoodTableViewCell", owner: self, options: nil)?.first as! AddFoodTableViewCell
            
            cell.mainImg.image = arrayOfCellData[indexPath.row].image
            cell.title.text = arrayOfCellData[indexPath.row].text
            
            return cell
        }
        else if arrayOfCellData[indexPath.row].cell == 2
        {
            let cell = Bundle.main.loadNibNamed("AddFoodTableViewCell", owner: self, options: nil)?.first as! AddFoodTableViewCell
            
            cell.mainImg.image = arrayOfCellData[indexPath.row].image
            cell.title.text = arrayOfCellData[indexPath.row].text
            
            return cell
        }
        else
        {
            let cell = Bundle.main.loadNibNamed("AddFoodTableViewCell", owner: self, options: nil)?.first as! AddFoodTableViewCell
            
            cell.mainImg.image = arrayOfCellData[indexPath.row].image
            cell.title.text = arrayOfCellData[indexPath.row].text
            
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if arrayOfCellData[indexPath.row].cell == 1
        {
            return 109
        }
        else if arrayOfCellData[indexPath.row].cell == 2
        {
            return 109
        }
        else
        {
            return 109
        }
        
    }
    
    
    // MARK: - Table view data source
    
    
}

