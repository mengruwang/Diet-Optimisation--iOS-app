//
//  CreateFood2ViewController.swift
//  DietOptimization
//
//  Created by Allen Geng on 17/1/12.
//  Copyright © 2017年 HD90+. All rights reserved.
//

import UIKit

class CreateFood2ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var arrayOfCellData = [cellData]()
    
    
    override func viewDidLoad() {
        
        arrayOfCellData = [cellData(cell: 1, text: "Beef", image: #imageLiteral(resourceName: "Icons-FoodsSketch")),
                           cellData(cell: 2, text: "Lamb", image: #imageLiteral(resourceName: "Icons-ReportSketch")),
                           cellData(cell: 3, text: "Chicken", image: #imageLiteral(resourceName: "Icons-DailySketch"))]
        
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayOfCellData.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 109
                
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = Bundle.main.loadNibNamed("AddFoodTableViewCell", owner: self, options: nil)?.first as! AddFoodTableViewCell
        
        
        cell.accessoryType = cell.isSelected ? .checkmark : .none
        cell.selectionStyle = .none // to prevent cells from being "highlighted"
        
        if arrayOfCellData[indexPath.row].cell == 1
        {
            cell.mainImg.image = arrayOfCellData[indexPath.row].image
            cell.title.text = arrayOfCellData[indexPath.row].text
            
            return cell
        }
        else if arrayOfCellData[indexPath.row].cell == 2
        {
            cell.mainImg.image = arrayOfCellData[indexPath.row].image
            cell.title.text = arrayOfCellData[indexPath.row].text
            
            return cell
        }
        else
        {
            cell.mainImg.image = arrayOfCellData[indexPath.row].image
            cell.title.text = arrayOfCellData[indexPath.row].text
            
            return cell
        }
        
    }
    
  
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
