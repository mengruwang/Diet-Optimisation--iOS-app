//
//  AddFoodTableTableViewController.swift
//  DietOptimization
//
//  Created by Allen Geng on 17/1/14.
//  Copyright © 2017年 HD90+. All rights reserved.
//

import UIKit


struct cellData {
    let cell: Int!
    let text: String!
    let image: UIImage!
    
}


class AddFoodTableTableViewController: UITableViewController {

    var arrayOfCellData = [cellData]()
    
    override func viewDidLoad() {
        arrayOfCellData = [cellData(cell: 1, text: "Beef", image: #imageLiteral(resourceName: "Icons-GoalSketch")),
                           cellData(cell: 2, text: "Lamb", image: #imageLiteral(resourceName: "Icons-PriceSketch")),
                           cellData(cell: 3, text: "Chicken", image: #imageLiteral(resourceName: "Icons-AccountSketch"))]
    }
    
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayOfCellData.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if arrayOfCellData[indexPath.row].cell == 1
        {
            let cell = Bundle.main.loadNibNamed("AddFoodTableViewCell", owner: self, options: nil)?.first as! AddFoodTableViewCell
            
            cell.mainImg.image = arrayOfCellData[indexPath.row].image
            cell.title.text = arrayOfCellData[indexPath.row].text
            
            return cell
        }
        else if arrayOfCellData[indexPath.row].cell == 2
        {
            let cell = Bundle.main.loadNibNamed("AddFoodTableViewCell", owner: self, options: nil)?.first as! AddFoodTableViewCell
            
            cell.mainImg.image = arrayOfCellData[indexPath.row].image
            cell.title.text = arrayOfCellData[indexPath.row].text
            
            return cell
        }
        else
        {
            let cell = Bundle.main.loadNibNamed("AddFoodTableViewCell", owner: self, options: nil)?.first as! AddFoodTableViewCell
            
            cell.mainImg.image = arrayOfCellData[indexPath.row].image
            cell.title.text = arrayOfCellData[indexPath.row].text
            
            return cell
        }
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if arrayOfCellData[indexPath.row].cell == 1
        {
            return 109
        }
        else if arrayOfCellData[indexPath.row].cell == 2
        {
            return 109
        }
        else
        {
            return 109
        }
        
    }


}
