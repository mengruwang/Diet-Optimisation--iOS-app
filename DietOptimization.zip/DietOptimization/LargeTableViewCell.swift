//
//  LargeTableViewCell.swift
//  DietOptimization
//
//  Created by Aquila on 30/01/2017.
//  Copyright © 2017 HD90+. All rights reserved.
//

import UIKit

class LargeTableViewCell: UITableViewCell {

    @IBOutlet weak var mainImageView: UIImageView!
    @IBOutlet weak var mainLabel: UILabel!
    @IBOutlet weak var potraitImageView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
